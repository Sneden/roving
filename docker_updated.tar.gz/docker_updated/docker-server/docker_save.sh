#!/bin/bash

#save docker progress via commit

docker images
docker commit server server:latest
docker images
docker-compose down

