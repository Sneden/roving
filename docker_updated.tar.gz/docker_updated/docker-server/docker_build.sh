#!/bin/bash

# Only for first build of docker server container

chmod +x docker_run.sh 
chmod +x docker_save.sh

docker-compose down
docker rmi -f server
yes | docker system prune
yes | docker image prune
docker network create --subnet=10.19.0.0/16 internet
docker build -t server .
docker-compose build 
docker-compose up -d
docker image ls
docker ps
docker exec -it server chmod +x build.sh
docker exec -it server ./build.sh
docker exec -it server /bin/bash


