#!/bin/bash

#run docker container

docker images
docker-compose build 
docker-compose up -d
docker ps
docker exec -it server /bin/bash


