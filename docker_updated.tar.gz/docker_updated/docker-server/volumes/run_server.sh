#!/bin/bash

#This script is used to run the server-side of fuzzer from inside the container 

cd /root/roving
./examples/c-server
