#!/bin/bash

# Only for first build of docker client1 container
chmod +x docker_run.sh 
chmod +x docker_save.sh
docker-compose down
docker rmi -f client1
yes | docker system prune
yes |docker image prune
docker build -t client1 .
docker-compose build 
docker-compose up -d
docker image ls
docker ps
docker exec -it client1 chmod +x build.sh
docker exec -it client1 ./build.sh
docker exec -it client1 /bin/bash


