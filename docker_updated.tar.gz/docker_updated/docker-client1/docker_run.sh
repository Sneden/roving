#!/bin/bash

#run docker container after built image

docker images
docker-compose build 
docker-compose up -d
docker ps
docker exec -it client1 /bin/bash


