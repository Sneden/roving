#!/bin/bash

#save docker progress via commit

docker images
docker commit client1 client1:latest
docker images
docker-compose down

