#!/bin/bash

#This script is used to run the client.

cd /root/roving
./examples/generic-client
