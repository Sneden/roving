#!/bin/bash

#This script is used to build the client side of the fuzzer.

chmod +x run_client.sh

cp -r /volumes/roving /root/

cd /root/roving/examples
chmod +x generic-client
chmod +x generic-client_build
cd ..
./examples/generic-client_build

sed -i 's/zlib\.net/zlib\.net\/fossils/' /root/.cache/bazel/_bazel_root/*/external/com_google_protobuf/protobuf_deps.bzl

sed -i 's/zlib\.net/zlib\.net\/fossils/' /root/.cache/bazel/_bazel_root/*/external/rules_proto/proto/private/dependencies.bzl

./examples/generic-client_build
