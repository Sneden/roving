#!/bin/bash

#save docker progress via commit

docker images
docker commit client2 client2:latest
docker images
docker-compose down

