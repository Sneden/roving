package server

var webfaceTemplates map[string]string
