#!/bin/bash

#This script runs the client for normal runs.
cd /root/roving
./examples/generic-client
