#!/bin/bash

# Only for first build of docker client2 container

chmod +x docker_run.sh 
chmod +x docker_save.sh
docker-compose down
docker rmi -f client2
yes | docker system prune
yes |docker image prune
docker build -t client2 .
docker-compose build 
docker-compose up -d
docker image ls
docker ps
docker exec -it client2 chmod +x build.sh
docker exec -it client2 ./build.sh
docker exec -it client2 /bin/bash


